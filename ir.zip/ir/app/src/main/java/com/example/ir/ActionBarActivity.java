package com.example.ir;

import android.os.Bundle;

class ActionBarActivity {
    protected void onStart() {
    }

    protected void onCreate(Bundle savedInstanceState) {
    }
}
